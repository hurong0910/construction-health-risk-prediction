# Construction Health Risk Prediction Dataset

This repository contains a curated and anonymized subset of wristband data collected from construction workers during highway construction activities. The dataset is intended for reproducibility of our research and academic use.

## Dataset Description
- **Physiological features**: Heart rate, body temperature, systolic blood pressure, diastolic blood pressure, blood oxygen saturation (SpO₂)
- **Behavioral features**: Step count
- **Spatiotemporal features**: Timestamp, GPS longitude, GPS latitude
- **Other metadata**: SectionID, PersonnelID, RecordID

All personally identifiable information (PII) has been removed. The dataset is anonymized and does not contain names, contact details, or device IDs.

## Citation
If you use this dataset, you must cite the following paper:

Hu, R. *et al.* (2025). *A Clinically Guided Machine Learning Framework for Predicting Health Risk in Construction Workers Using Wearable Data.* [Manuscript submitted].

## License
- **Code**: MIT License
- **Dataset**: CC BY 4.0 (Attribution Required)
